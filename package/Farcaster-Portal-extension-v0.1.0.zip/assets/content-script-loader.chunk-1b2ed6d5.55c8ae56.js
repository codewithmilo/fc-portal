(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-1b2ed6d5.js")
    );
  })().catch(console.error);

})();
